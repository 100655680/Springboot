package com.dartsapp.controller;

import com.dartsapp.model.Game;
import com.dartsapp.model.GameStat;
import com.dartsapp.model.GameTurn;
import com.dartsapp.model.User;
import com.dartsapp.repository.GameRepository;
import com.dartsapp.repository.GameStatRepository;
import com.dartsapp.repository.GameTurnRepository;
import com.dartsapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/api/games")
public class GameController {
    @Autowired private GameRepository     gameRepo;
    @Autowired private UserRepository     userRepo;
    @Autowired private GameTurnRepository turnRepo;
    @Autowired private GameStatRepository statRepo;

    /**
     * Start a new game. Supports both POST (normal) and GET (browser hit).
     */
    @RequestMapping(method = {RequestMethod.POST, RequestMethod.GET})
    public Long startGame(@RequestParam Long opponentId, Principal principal) {
        User me       = userRepo.findByUsername(principal.getName()).orElseThrow();
        User opponent = userRepo.findById(opponentId).orElseThrow();

        Game game = gameRepo.save(new Game());

        // seed stats for both players; convert Integer IDs to Long
        GameStat.StatId id1 = new GameStat.StatId(
            game.getGameId(),
            me.getId().longValue()
        );
        GameStat.StatId id2 = new GameStat.StatId(
            game.getGameId(),
            opponent.getId().longValue()
        );
        statRepo.save(new GameStat(id1));
        statRepo.save(new GameStat(id2));

        return game.getGameId();
    }

    /**
     * Record a turn for the given gameId.
     */
    @PostMapping("/{gameId}/turns")
    public int addTurn(@PathVariable Long gameId,
                       @RequestParam int score,
                       @RequestParam(defaultValue = "3") int dartsThrown,
                       Principal principal) {
        User me   = userRepo.findByUsername(principal.getName()).orElseThrow();
        Game game = gameRepo.findById(gameId).orElseThrow();

        int turnNumber = turnRepo.countByGameAndUser(game, me) + 1;

        // save the turn
        GameTurn turn = new GameTurn();
        turn.setGame(game);
        turn.setUser(me);
        turn.setTurnNumber(turnNumber);
        turn.setDartsThrown(dartsThrown);
        turn.setScore(score);
        turnRepo.save(turn);

        // update stats, converting user ID to Long
        GameStat.StatId sid = new GameStat.StatId(
            gameId,
            me.getId().longValue()
        );
        GameStat stats = statRepo.findById(sid).orElseThrow();
        stats.setTotalDarts(stats.getTotalDarts() + dartsThrown);
        if (score == 120) stats.setCount120s(stats.getCount120s() + 1);
        else if (score == 140) stats.setCount140s(stats.getCount140s() + 1);
        else if (score == 180) stats.setCount180s(stats.getCount180s() + 1);
        else if (score > 100) stats.setCount100Plus(stats.getCount100Plus() + 1);
        statRepo.save(stats);

        return turnNumber;
    }
}
