package com.dartsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DartsAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(DartsAppApplication.class, args);
    }
}
